while (A)
	       do
		   until C
 do D
   done
done

#test

if A
then B
else C
fi

if a
then b #testing
fi

g++ -o foo foo.c
true
: : :

(true)
((false))

a<b
b>c
